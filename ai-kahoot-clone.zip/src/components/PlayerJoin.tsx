import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface PlayerJoinProps {
  onJoin: (gameId: string, name: string) => void;
  initialGameId?: string;
}

export function PlayerJoin({ onJoin, initialGameId = '' }: PlayerJoinProps) {
  const [gameId, setGameId] = useState(initialGameId);
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (gameId && name) {
      onJoin(gameId.toUpperCase(), name);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-purple-700 p-4">
      <Card className="w-full max-w-md shadow-2xl border-none">
        <CardHeader className="text-center space-y-1">
          <CardTitle className="text-3xl font-black tracking-tighter text-primary">AI QUIZ</CardTitle>
          <CardDescription className="text-lg">Nhập mã phòng để tham gia</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="gameId">Mã phòng</Label>
              <Input
                id="gameId"
                placeholder="VÍ DỤ: ABCXYZ"
                value={gameId}
                onChange={(e) => setGameId(e.target.value.toUpperCase())}
                className="h-12 text-center text-2xl font-bold tracking-widest uppercase"
                maxLength={6}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Tên của bạn</Label>
              <Input
                id="name"
                placeholder="Nhập tên..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-12 text-lg"
                required
              />
            </div>
            <Button type="submit" className="w-full h-14 text-xl font-bold bg-primary hover:bg-primary/90 transition-all active:scale-95">
              THAM GIA
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
