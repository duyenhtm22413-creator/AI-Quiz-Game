import React from 'react';
import { GameState, Player } from '../types';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Users, Timer, Trophy, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GameRoomProps {
  gameState: GameState;
  playerId: string;
  onStart: () => void;
  onSubmitAnswer: (index: number) => void;
  onNext: () => void;
}

export function GameRoom({ gameState, playerId, onStart, onSubmitAnswer, onNext }: GameRoomProps) {
  const isHost = gameState.players.length > 0 && gameState.players[0].id === playerId;
  const currentPlayer = gameState.players.find(p => p.id === playerId);

  if (gameState.status === 'waiting') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <div className="text-center space-y-4 mb-12">
          <h1 className="text-5xl font-black text-slate-900">SẴN SÀNG CHƯA?</h1>
          <div className="bg-white px-8 py-4 rounded-2xl shadow-lg border-4 border-primary inline-block">
            <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Mã phòng</p>
            <p className="text-6xl font-black text-primary tracking-tighter">{gameState.id}</p>
          </div>
        </div>

        <div className="w-full max-w-4xl grid grid-cols-2 md:grid-cols-4 gap-4">
          <AnimatePresence>
            {gameState.players.map((player) => (
              <motion.div
                key={player.id}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                className="bg-white p-4 rounded-xl shadow-md flex items-center gap-3 border-2 border-transparent hover:border-primary transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                  {player.name[0].toUpperCase()}
                </div>
                <span className="font-bold text-slate-700 truncate">{player.name}</span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="mt-12 flex flex-col items-center gap-4">
          <div className="flex items-center gap-2 text-slate-500 font-medium">
            <Users className="h-5 w-5" />
            <span>{gameState.players.length} người đang đợi</span>
          </div>
          {isHost && gameState.players.length > 0 && (
            <Button onClick={onStart} className="h-16 px-12 text-2xl font-black bg-green-600 hover:bg-green-700 shadow-xl active:scale-95 transition-all">
              BẮT ĐẦU NGAY
            </Button>
          )}
          {!isHost && <p className="text-slate-400 animate-pulse">Đang đợi chủ phòng bắt đầu...</p>}
        </div>
      </div>
    );
  }

  if (gameState.status === 'playing') {
    const question = gameState.questions[gameState.currentQuestionIndex];
    const hasAnswered = currentPlayer?.hasAnswered;

    return (
      <div className="min-h-screen bg-slate-100 flex flex-col">
        <div className="bg-white p-4 shadow-sm flex justify-between items-center">
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="text-lg px-4 py-1">
              Câu {gameState.currentQuestionIndex + 1} / {gameState.questions.length}
            </Badge>
          </div>
          <div className="flex items-center gap-2 text-2xl font-black text-primary">
            <Timer className="h-8 w-8" />
            <span className={gameState.timer <= 5 ? "text-destructive animate-bounce" : ""}>
              {gameState.timer}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span className="font-bold">{currentPlayer?.score || 0}</span>
          </div>
        </div>

        <div className="flex-1 flex flex-col p-6 gap-6">
          <Card className="flex-1 flex items-center justify-center p-8 text-center shadow-xl border-none">
            <CardHeader>
              <CardTitle className="text-3xl md:text-5xl font-bold leading-tight">
                {question.text}
              </CardTitle>
            </CardHeader>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-[40%]">
            {question.options.map((option, index) => {
              const colors = [
                'bg-red-500 hover:bg-red-600',
                'bg-blue-500 hover:bg-blue-600',
                'bg-yellow-500 hover:bg-yellow-600',
                'bg-green-500 hover:bg-green-600'
              ];
              const shapes = ['▲', '◆', '●', '■'];

              return (
                <Button
                  key={index}
                  disabled={hasAnswered}
                  onClick={() => onSubmitAnswer(index)}
                  className={`${colors[index]} h-full text-xl md:text-2xl font-bold flex items-center justify-start px-8 gap-6 shadow-lg transition-all active:scale-95 disabled:opacity-50`}
                >
                  <span className="text-3xl opacity-50">{shapes[index]}</span>
                  <span className="flex-1 text-left line-clamp-2">{option}</span>
                </Button>
              );
            })}
          </div>
        </div>

        {hasAnswered && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white p-8 rounded-3xl text-center space-y-4"
            >
              <div className="text-6xl animate-bounce">🤔</div>
              <h2 className="text-3xl font-black">ĐÃ NHẬN CÂU TRẢ LỜI!</h2>
              <p className="text-slate-500">Đang đợi những người chơi khác...</p>
            </motion.div>
          </div>
        )}
      </div>
    );
  }

  if (gameState.status === 'results') {
    const question = gameState.questions[gameState.currentQuestionIndex];
    const correct = currentPlayer?.lastAnswerCorrect;

    return (
      <div className={`min-h-screen flex flex-col items-center justify-center p-6 transition-colors duration-500 ${correct ? 'bg-green-500' : 'bg-red-500'}`}>
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-white p-12 rounded-3xl shadow-2xl text-center max-w-2xl w-full space-y-8"
        >
          <div className="flex justify-center">
            {correct ? (
              <CheckCircle2 className="h-32 w-32 text-green-500" />
            ) : (
              <XCircle className="h-32 w-32 text-red-500" />
            )}
          </div>
          
          <div className="space-y-2">
            <h2 className="text-5xl font-black uppercase tracking-tighter">
              {correct ? 'CHÍNH XÁC!' : 'SAI RỒI!'}
            </h2>
            <p className="text-slate-500 text-xl font-medium">
              Đáp án đúng là: <span className="font-bold text-slate-900">{question.options[question.correctAnswer]}</span>
            </p>
          </div>

          <div className="bg-slate-50 p-6 rounded-2xl flex justify-between items-center">
            <div className="text-left">
              <p className="text-sm font-bold text-slate-400 uppercase">Điểm hiện tại</p>
              <p className="text-4xl font-black text-slate-900">{currentPlayer?.score || 0}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold text-slate-400 uppercase">Thứ hạng</p>
              <p className="text-4xl font-black text-slate-900">
                #{gameState.players.sort((a, b) => b.score - a.score).findIndex(p => p.id === playerId) + 1}
              </p>
            </div>
          </div>

          {isHost && (
            <Button onClick={onNext} className="w-full h-16 text-2xl font-black bg-slate-900 hover:bg-slate-800 text-white">
              CÂU TIẾP THEO
            </Button>
          )}
        </motion.div>
      </div>
    );
  }

  if (gameState.status === 'finished') {
    const sortedPlayers = [...gameState.players].sort((a, b) => b.score - a.score);
    const podium = sortedPlayers.slice(0, 3);

    return (
      <div className="min-h-screen bg-indigo-900 flex flex-col items-center justify-center p-6 text-white">
        <h1 className="text-6xl font-black mb-12 tracking-tighter">BẢNG VÀNG</h1>
        
        <div className="flex items-end gap-4 mb-12 h-64">
          {/* 2nd Place */}
          {podium[1] && (
            <div className="flex flex-col items-center gap-2">
              <div className="font-bold text-xl">{podium[1].name}</div>
              <div className="bg-indigo-700 w-32 h-32 flex items-center justify-center text-4xl font-black rounded-t-xl border-t-4 border-slate-300">2</div>
              <div className="text-slate-300 font-bold">{podium[1].score}</div>
            </div>
          )}
          {/* 1st Place */}
          {podium[0] && (
            <div className="flex flex-col items-center gap-2">
              <Trophy className="h-12 w-12 text-yellow-400 animate-bounce" />
              <div className="font-bold text-2xl">{podium[0].name}</div>
              <div className="bg-indigo-600 w-40 h-48 flex items-center justify-center text-6xl font-black rounded-t-xl border-t-4 border-yellow-400">1</div>
              <div className="text-yellow-400 font-bold text-xl">{podium[0].score}</div>
            </div>
          )}
          {/* 3rd Place */}
          {podium[2] && (
            <div className="flex flex-col items-center gap-2">
              <div className="font-bold text-xl">{podium[2].name}</div>
              <div className="bg-indigo-800 w-32 h-24 flex items-center justify-center text-4xl font-black rounded-t-xl border-t-4 border-amber-600">3</div>
              <div className="text-amber-600 font-bold">{podium[2].score}</div>
            </div>
          )}
        </div>

        <div className="w-full max-w-md space-y-2">
          {sortedPlayers.slice(3).map((player, index) => (
            <div key={player.id} className="bg-white/10 p-4 rounded-xl flex justify-between items-center">
              <div className="flex items-center gap-4">
                <span className="font-bold opacity-50">#{index + 4}</span>
                <span className="font-bold">{player.name}</span>
              </div>
              <span className="font-mono">{player.score}</span>
            </div>
          ))}
        </div>

        <Button onClick={() => window.location.reload()} className="mt-12 bg-white text-indigo-900 hover:bg-white/90 font-bold px-8 py-6 text-xl">
          CHƠI LẠI
        </Button>
      </div>
    );
  }

  return null;
}
