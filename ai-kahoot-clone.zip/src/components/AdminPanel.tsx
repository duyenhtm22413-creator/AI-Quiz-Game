import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ScrollArea } from './ui/scroll-area';
import { generateQuestionsFromContent } from '../lib/gemini';
import { Question } from '../types';
import { Loader2, Plus, Sparkles, Trash2 } from 'lucide-react';

interface AdminPanelProps {
  onCreateGame: (questions: Question[]) => void;
}

export function AdminPanel({ onCreateGame }: AdminPanelProps) {
  const [content, setContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);

  const handleGenerate = async () => {
    if (!content.trim()) return;
    setIsGenerating(true);
    try {
      const generated = await generateQuestionsFromContent(content);
      setQuestions(generated);
    } catch (error) {
      console.error('Failed to generate questions:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const addQuestion = () => {
    const newQuestion: Question = {
      id: `q-${Date.now()}`,
      text: 'Câu hỏi mới',
      options: ['Lựa chọn 1', 'Lựa chọn 2', 'Lựa chọn 3', 'Lựa chọn 4'],
      correctAnswer: 0
    };
    setQuestions([...questions, newQuestion]);
  };

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setQuestions(questions.map(q => q.id === id ? { ...q, ...updates } : q));
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <Card className="border-2 border-primary/20 shadow-xl">
        <CardHeader className="bg-primary/5">
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Sparkles className="text-primary" />
            Tạo Trò Chơi Với AI
          </CardTitle>
          <CardDescription>
            Nhập nội dung kiến thức, AI sẽ tự động tạo bộ câu hỏi trắc nghiệm cho bạn.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="content">Nội dung kiến thức</Label>
            <textarea
              id="content"
              className="w-full min-h-[150px] p-3 rounded-md border border-input bg-background text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="Ví dụ: Lịch sử Việt Nam thời kỳ nhà Trần..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
          </div>
          <Button 
            onClick={handleGenerate} 
            disabled={isGenerating || !content.trim()}
            className="w-full"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Đang tạo câu hỏi...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Tạo câu hỏi bằng AI
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {questions.length > 0 && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Danh sách câu hỏi ({questions.length})</h2>
            <Button variant="outline" size="sm" onClick={addQuestion}>
              <Plus className="mr-2 h-4 w-4" /> Thêm câu hỏi
            </Button>
          </div>
          
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {questions.map((q, qIndex) => (
                <Card key={q.id} className="relative group">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-destructive"
                    onClick={() => removeQuestion(q.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <CardHeader>
                    <CardTitle className="text-lg">Câu {qIndex + 1}</CardTitle>
                    <Input 
                      value={q.text} 
                      onChange={(e) => updateQuestion(q.id, { text: e.target.value })}
                      className="mt-2"
                    />
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    {q.options.map((opt, optIndex) => (
                      <div key={optIndex} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name={`correct-${q.id}`}
                          checked={q.correctAnswer === optIndex}
                          onChange={() => updateQuestion(q.id, { correctAnswer: optIndex })}
                          className="h-4 w-4 text-primary"
                        />
                        <Input 
                          value={opt} 
                          onChange={(e) => {
                            const newOpts = [...q.options];
                            newOpts[optIndex] = e.target.value;
                            updateQuestion(q.id, { options: newOpts });
                          }}
                          className={q.correctAnswer === optIndex ? "border-green-500 bg-green-50" : ""}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>

          <Button 
            className="w-full h-16 text-xl font-bold bg-green-600 hover:bg-green-700"
            onClick={() => onCreateGame(questions)}
          >
            BẮT ĐẦU TRÒ CHƠI
          </Button>
        </div>
      )}
    </div>
  );
}
