export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface GameState {
  id: string;
  status: 'waiting' | 'starting' | 'playing' | 'results' | 'finished';
  questions: Question[];
  currentQuestionIndex: number;
  players: Player[];
  timer: number;
}

export interface Player {
  id: string;
  name: string;
  score: number;
  lastAnswerCorrect: boolean | null;
  hasAnswered: boolean;
}

export interface ServerToClientEvents {
  gameUpdate: (gameState: GameState) => void;
  playerJoined: (player: Player) => void;
  gameStarted: () => void;
  nextQuestion: (index: number) => void;
  showResults: (results: any) => void;
  error: (message: string) => void;
}

export interface ClientToServerEvents {
  createGame: (questions: Question[]) => void;
  joinGame: (gameId: string, playerName: string) => void;
  startGame: (gameId: string) => void;
  submitAnswer: (gameId: string, answerIndex: number) => void;
  nextQuestion: (gameId: string) => void;
}
