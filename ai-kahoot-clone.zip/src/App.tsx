import { useState } from 'react';
import { useSocket } from './hooks/useSocket';
import { AdminPanel } from './components/AdminPanel';
import { PlayerJoin } from './components/PlayerJoin';
import { GameRoom } from './components/GameRoom';
import { Button } from './components/ui/button';
import { AlertCircle, Gamepad2, Settings } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from './components/ui/alert';

export default function App() {
  const { socket, gameState, error, setError } = useSocket();
  const [view, setView] = useState<'home' | 'admin' | 'join'>('home');

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Lỗi</AlertTitle>
          <AlertDescription className="flex flex-col gap-4">
            {error}
            <Button onClick={() => { setError(null); setView('home'); }}>Quay lại trang chủ</Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (gameState && socket) {
    return (
      <GameRoom
        gameState={gameState}
        playerId={socket.id || ''}
        onStart={() => socket.emit('startGame', gameState.id)}
        onSubmitAnswer={(index) => socket.emit('submitAnswer', gameState.id, index)}
        onNext={() => socket.emit('nextQuestion', gameState.id)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {view === 'home' && (
        <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
          <div className="text-center space-y-6 mb-12">
            <h1 className="text-7xl md:text-9xl font-black text-white tracking-tighter drop-shadow-2xl">
              AI QUIZ
            </h1>
            <p className="text-xl md:text-2xl text-white/90 font-medium max-w-lg mx-auto">
              Trò chơi trắc nghiệm thông minh tích hợp AI Gemini. 
              Tạo đề thi chỉ trong vài giây!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-2xl">
            <Button 
              onClick={() => setView('join')}
              className="h-32 text-3xl font-black bg-white text-indigo-600 hover:bg-white/90 shadow-2xl active:scale-95 transition-all rounded-3xl"
            >
              <Gamepad2 className="mr-4 h-10 w-10" />
              THAM GIA
            </Button>
            <Button 
              onClick={() => setView('admin')}
              variant="outline"
              className="h-32 text-3xl font-black bg-indigo-600/20 text-white border-white/40 hover:bg-indigo-600/30 backdrop-blur-md shadow-2xl active:scale-95 transition-all rounded-3xl"
            >
              <Settings className="mr-4 h-10 w-10" />
              QUẢN TRỊ
            </Button>
          </div>

          <div className="mt-16 text-white/60 text-sm font-medium uppercase tracking-widest">
            Powered by Google Gemini AI
          </div>
        </div>
      )}

      {view === 'admin' && socket && (
        <div className="p-4">
          <Button variant="ghost" onClick={() => setView('home')} className="mb-4">
            ← Quay lại
          </Button>
          <AdminPanel onCreateGame={(questions) => socket.emit('createGame', questions)} />
        </div>
      )}

      {view === 'join' && socket && (
        <div className="relative">
          <Button 
            variant="ghost" 
            onClick={() => setView('home')} 
            className="absolute top-4 left-4 text-white hover:bg-white/20 z-10"
          >
            ← Quay lại
          </Button>
          <PlayerJoin onJoin={(id, name) => socket.emit('joinGame', id, name)} />
        </div>
      )}
    </div>
  );
}

