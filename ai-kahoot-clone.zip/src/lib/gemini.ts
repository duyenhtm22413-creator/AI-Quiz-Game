import { GoogleGenAI, Type } from "@google/genai";
import { Question } from "../types.js";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export async function generateQuestionsFromContent(content: string): Promise<Question[]> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Dựa trên nội dung sau, hãy tạo ra 5 câu hỏi trắc nghiệm tiếng Việt theo phong cách Kahoot. 
    Mỗi câu hỏi phải có 4 lựa chọn và chỉ có 1 đáp án đúng.
    Nội dung: ${content}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING, description: "Nội dung câu hỏi" },
            options: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Danh sách 4 lựa chọn"
            },
            correctAnswer: { 
              type: Type.INTEGER, 
              description: "Chỉ số của đáp án đúng (0-3)" 
            }
          },
          required: ["text", "options", "correctAnswer"]
        }
      }
    }
  });

  const questionsData = JSON.parse(response.text || "[]");
  return questionsData.map((q: any, index: number) => ({
    ...q,
    id: `q-${index}-${Date.now()}`
  }));
}
